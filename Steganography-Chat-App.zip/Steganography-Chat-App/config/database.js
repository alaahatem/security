module.exports = {
  database: 'mongodb://superadmin:123admin123@ds147946.mlab.com:47946/steganography-chat'
}
