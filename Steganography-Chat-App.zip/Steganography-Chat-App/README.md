# Steganography-Chat

Steganography-Chat is a javascript web app.

## Installation

Use the node package manager [npm] inside 'Steganography-Chat' project folder and inside 'Steganography-Chat/client/'

```bash
npm install
```

## Usage

```bash
node server
```

or 

```bash
nodemon
```


Visit http://localhost:3000 for local or you can try it live on http://steganography-chat.herokuapp.com/
